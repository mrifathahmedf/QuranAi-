/* QuranAI service worker v4 — network-first navigation (no more stale/broken pages) */
const CACHE='quranai-v4';
const CORE=['/','/index.html','/about.html','/contact.html','/privacy.html'];
self.addEventListener('install',e=>{self.skipWaiting();e.waitUntil(caches.open(CACHE).then(c=>c.addAll(CORE).catch(()=>{})));});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim()));});
self.addEventListener('message',e=>{if(e.data==='skipWaiting')self.skipWaiting();});
function swr(req){return caches.open(CACHE).then(cache=>cache.match(req).then(cached=>{const net=fetch(req).then(res=>{if(res&&res.ok)cache.put(req,res.clone());return res;}).catch(()=>cached);return cached||net;}));}
// network-first: always try live, fall back to cache only when offline
function networkFirst(req){return caches.open(CACHE).then(cache=>fetch(req).then(res=>{if(res&&res.ok)cache.put(req,res.clone());return res;}).catch(()=>cache.match(req).then(c=>c||cache.match('/index.html'))));}
self.addEventListener('fetch',e=>{
  const req=e.request; if(req.method!=='GET')return;
  let url; try{url=new URL(req.url);}catch(_){return;}
  const sameOrigin=url.origin===location.origin;
  if(req.mode==='navigate'){ e.respondWith(networkFirst(req)); return; }
  if(sameOrigin){ e.respondWith(swr(req)); return; }
  e.respondWith(networkFirst(req));
});